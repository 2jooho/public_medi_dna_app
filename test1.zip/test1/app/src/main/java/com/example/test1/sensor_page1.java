package com.example.test1;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
/*import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;*/
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.test1.sensor_subbutton.sensor_sub1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class sensor_page1 extends AppCompatActivity {
    Button btn1,btn2,btn3,btn4,btn5;
    TextView line1, line2;
    private FragmentManager fragmentManager;
    private sensor_sub1 sensor_sub1;
    private sensor_fragment_page1_fan sensor_fragment_page1_fan;
    private FragmentTransaction transaction;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_main);
        btn1=(Button)findViewById(R.id.information_btn);
        line1=(TextView)findViewById(R.id.information_line);

        fragmentManager=getSupportFragmentManager();
        sensor_sub1= new sensor_sub1();
        sensor_fragment_page1_fan=new sensor_fragment_page1_fan();

        transaction =fragmentManager.beginTransaction();
        transaction.replace(R.id.framelayout, sensor_sub1).commitAllowingStateLoss();
}
    @SuppressLint("ResourceAsColor")
    public void clickHandler(View view)
    {
        transaction = fragmentManager.beginTransaction();

        switch(view.getId())
        {
            case R.id.information_btn:
                transaction.replace(R.id.framelayout, sensor_sub1).commitAllowingStateLoss();
                switch (view.getId()){
                    case R.id.fan:
                        transaction.replace(R.id.framelayout2, sensor_fragment_page1_fan).commitAllowingStateLoss();
                }
                break;

        }
    }
}