package com.example.test1.gene_button;

import android.annotation.SuppressLint;
import android.os.Bundle;
/*import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;*/
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.test1.R;

public class bmibutton extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.bmi_button, container, false);

   /*     ImageView imageView = view.findViewById(R.id.imagebtn1);
        ImageView imageView2 = view.findViewById(R.id.imagebtn2);
         if (getArguments() != null) {
            Bundle args = getArguments();
    *//*        // MainActivity에서 받아온 Resource를 ImageView에 셋팅
            imageView.setImageResource(args.getInt("imgRes"));*//*
        }*/

        return view;
    }
}
