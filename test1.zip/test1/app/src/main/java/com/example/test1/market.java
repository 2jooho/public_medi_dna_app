package com.example.test1;

import android.annotation.SuppressLint;
import android.os.Bundle;
/*import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;*/
import android.widget.Button;

import com.example.test1.gene_button.aging;
import com.example.test1.gene_button.alopecia;
import com.example.test1.gene_button.bmibutton;
import com.example.test1.gene_button.caffeine;
import com.example.test1.gene_button.elasticity;
import com.example.test1.gene_button.glucose;
import com.example.test1.gene_button.hair;
import com.example.test1.gene_button.male;
import com.example.test1.gene_button.pigmentation;
import com.example.test1.gene_button.pressure;
import com.example.test1.gene_button.total;
import com.example.test1.gene_button.triglybutton2;
import com.example.test1.gene_button.vitamin;
import com.example.test1.market_button.market_item1;
import com.example.test1.market_button.market_item2;
import com.example.test1.market_button.market_item3;
import com.example.test1.market_button.market_item4;
import com.example.test1.market_button.market_item5;

import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

public class market extends AppCompatActivity {
    Button btn1,btn2,btn3,btn4,btn5;

    private FragmentManager fragmentManager;
    private market_item1 Fragment_item1;
    private market_item2 Fragment_item2;
    private FragmentTransaction transaction;

    @SuppressLint("WrongViewCast")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_market);

        btn1=(Button)findViewById(R.id.imagebtn_item1);
        btn2=(Button)findViewById(R.id.imagebtn_item2);


        ViewPager viewPager = findViewById(R.id.viewPager);
        FragmentAdapter_market fragmentAdapter = new FragmentAdapter_market(getSupportFragmentManager());
// ViewPager와  FragmentAdapter 연결
        viewPager.setAdapter(fragmentAdapter);

        viewPager.setClipToPadding(false);
        int dpValue = 40;
        float d = getResources().getDisplayMetrics().density;
        int margin = (int) (dpValue * d);
        viewPager.setPadding(margin, 0, (margin*2)+(int)(160*d), 0);
        viewPager.setPageMargin(margin/20);



        market_item1 imageFragment = new market_item1();
        market_item2 imageFragment2 = new market_item2();
        market_item3 imageFragment3 = new market_item3();
        market_item4 imageFragment4 = new market_item4();
        market_item5 imageFragment5 = new market_item5();

        // imageFragment.setArguments();
        fragmentAdapter.addItem(imageFragment);
        fragmentAdapter.addItem(imageFragment2);
        fragmentAdapter.addItem(imageFragment3);
        fragmentAdapter.addItem(imageFragment4);
        fragmentAdapter.addItem(imageFragment5);

        fragmentAdapter.notifyDataSetChanged();
    }
}
class FragmentAdapter_market extends FragmentPagerAdapter {

    // ViewPager에 들어갈 Fragment들을 담을 리스트
    private ArrayList<Fragment> fragments = new ArrayList<>();

    // 필수 생성자

    public FragmentAdapter_market(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        return fragments.get(position);
    }

    @Override
    public int getCount() {
        return fragments.size();
    }

    // List에 Fragment를 담을 함수
    void addItem(Fragment fragment) {
        fragments.add(fragment);
    }
}
