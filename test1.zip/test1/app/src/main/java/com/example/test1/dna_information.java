package com.example.test1;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
/*import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;*/
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.example.test1.gene_button.aging;
import com.example.test1.gene_button.alopecia;
import com.example.test1.gene_button.bmibutton;
import com.example.test1.gene_button.caffeine;
import com.example.test1.gene_button.elasticity;
import com.example.test1.gene_button.glucose;
import com.example.test1.gene_button.hair;
import com.example.test1.gene_button.male;
import com.example.test1.gene_button.pigmentation;
import com.example.test1.gene_button.pressure;
import com.example.test1.gene_button.total;
import com.example.test1.gene_button.triglybutton2;
import com.example.test1.gene_button.vitamin;
import com.example.test1.gene_result.bmi_result;
import com.example.test1.gene_result.trigly_result;

import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

public class dna_information extends AppCompatActivity {

    Button bmi,tri2, vita,total,pressure,pigmentaion, male, hair,glucose, elasticity
            ,cafe,aging, alopecia;

    private FragmentManager fragmentManager;
    private bmi_result Fragment_bmi;
    private trigly_result Fragment_trigly;
    private FragmentTransaction transaction;

    @SuppressLint("WrongViewCast")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dna_information);

        bmi=(Button)findViewById(R.id.imagebtn_bmi);
        tri2=(Button)findViewById(R.id.imagebtn_trigly);


        fragmentManager=getSupportFragmentManager();

        Fragment_bmi= new bmi_result();
        Fragment_trigly= new trigly_result();

        transaction =fragmentManager.beginTransaction();
        transaction.replace(R.id.framelayout, Fragment_bmi).commitAllowingStateLoss();

        ViewPager viewPager = findViewById(R.id.viewPager);
        FragmentAdapter fragmentAdapter = new FragmentAdapter(getSupportFragmentManager());
// ViewPager와  FragmentAdapter 연결
        viewPager.setAdapter(fragmentAdapter);

        viewPager.setClipToPadding(false);
        int dpValue = 40;
       float d = getResources().getDisplayMetrics().density;
        int margin = (int) (dpValue * d);
        viewPager.setPadding(margin, 0, (margin*2)+(int)(20*d), 0);
        viewPager.setPageMargin(margin/20);

      /*  ArrayList<Integer> listImage = new ArrayList<>();
        listImage.add(1);

        for (int i = 0; i < listImage.size(); i++) {
            bmibutton imageFragment = new bmibutton();
            Bundle bundle = new Bundle();
            bundle.putInt("imgRes", listImage.get(i));
            imageFragment.setArguments(bundle);
            fragmentAdapter.addItem(imageFragment);
        }*/
        bmibutton imageFragment = new bmibutton();
        triglybutton2 imageFragment2 = new triglybutton2();
        total imageFragment3 = new total();
        glucose imageFragment4 = new glucose();
        pressure imageFragment5 = new pressure();
        caffeine imageFragment6 = new caffeine();
        aging imageFragment7 = new aging();
        elasticity imageFragment8 = new elasticity();
        pigmentation imageFragment9 = new pigmentation();
        male imageFragment10 = new male();
        alopecia imageFragment11 = new alopecia();
        hair imageFragment12 = new hair();
        vitamin imageFragment13 = new vitamin();

       // imageFragment.setArguments();
        fragmentAdapter.addItem(imageFragment);
        fragmentAdapter.addItem(imageFragment2);
        fragmentAdapter.addItem(imageFragment3);
        fragmentAdapter.addItem(imageFragment4);
        fragmentAdapter.addItem(imageFragment5);
        fragmentAdapter.addItem(imageFragment6);
        fragmentAdapter.addItem(imageFragment7);
        fragmentAdapter.addItem(imageFragment8);
        fragmentAdapter.addItem(imageFragment9);
        fragmentAdapter.addItem(imageFragment10);
        fragmentAdapter.addItem(imageFragment11);
        fragmentAdapter.addItem(imageFragment12);
        fragmentAdapter.addItem(imageFragment13);
        //
        fragmentAdapter.notifyDataSetChanged();
    }


    @SuppressLint("ResourceAsColor")
    public void clickHandler(View view)
    {
        transaction = fragmentManager.beginTransaction();

        switch(view.getId())
        {
            case R.id.imagebtn_bmi:
                btn_shape btn_shape=new btn_shape();
                transaction.replace(R.id.framelayout, Fragment_bmi).commitAllowingStateLoss();
               // btn_shape.btn_change();
               // bmi.setBackgroundResource(R.drawable.dna_btn);

               // bmi.setTextColor(Color.parseColor("#000000"));
             //   tri2.setTextColor(R.color.enable);
                break;

            case R.id.imagebtn_trigly:
                transaction.replace(R.id.framelayout, Fragment_trigly).commitAllowingStateLoss();

                break;
        }
    }


}
class FragmentAdapter extends FragmentPagerAdapter {

    // ViewPager에 들어갈 Fragment들을 담을 리스트
    private ArrayList<Fragment> fragments = new ArrayList<>();

    // 필수 생성자
    FragmentAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        return fragments.get(position);
    }

    @Override
    public int getCount() {
        return fragments.size();
    }

    // List에 Fragment를 담을 함수
    void addItem(Fragment fragment) {
        fragments.add(fragment);
    }
}
class btn_shape extends Activity {

    //ImageButton bmi,tri2, vita,total,pressure,pigmentaion, male, hair,glucose, elasticity
      //      ,caffe,aging, alopecia;
    @SuppressLint("WrongViewCast")

    public void btn_change()
    {
        ImageButton[] imagebtn=new ImageButton[13];
        TextView[] textview=new TextView[13];
        TextView[] text_item=new TextView[13];
        TextView[] text_gene=new TextView[13];

        int[] btn_name={R.id.imagebtn_bmi,R.id.imagebtn_trigly,R.id.imagebtn_vita,
                R.id.imagebtn_total,R.id.imagebtn_pres,R.id.imagebtn_pig,R.id.imagebtn_male
                , R.id.imagebtn_hair,R.id.imagebtn_glucose,R.id.imagebtn_elastic,R.id.imagebtn_caffe
                , R.id.imagebtn_aging,R.id.imagebtn_alope };
        int[] tv_name={R.id.textview_bmi,R.id.textview_trigly,R.id.textview_vita,R.id.textview_total,
            R.id.textview_pres,R.id.textview_pig,R.id.textview_male,R.id.textview_hair, R.id.textview_glucose,
            R.id.textview_elastic,R.id.textview_caffe,R.id.textview_aging,R.id.textview_alope};
        int[] tv_item={R.id.item_bmi,R.id.item_trigly,R.id.item_vita,R.id.item_total,R.id.item_pres,R.id.item_pig
             ,R.id.item_male,R.id.item_hair,R.id.item_glucose,R.id.item_elastic,
                R.id.item_caffe,R.id.item_aging,R.id.item_alope};
        int[] tv_gene={R.id.gene_bmi,R.id.gene_trigly,R.id.gene_vita,R.id.gene_total,R.id.gene_pres,R.id.gene_pig
        ,R.id.gene_male,R.id.gene_hair,R.id.gene_glucose,R.id.gene_elastic,R.id.gene_caffe,R.id.gene_aging,R.id.gene_alope};

      for(int i=0;i<btn_name.length;i++){
          imagebtn[i]=(ImageButton)findViewById(btn_name[i]);
          textview[i]=(TextView)findViewById(tv_name[i]);
          text_item[i]=(TextView)findViewById(tv_item[i]);
          text_gene[i]=(TextView)findViewById(tv_gene[i]);
          imagebtn[i].setBackgroundResource(R.drawable.shape2);
          textview[i].setBackgroundResource(R.drawable.shape2);
          text_item[i].setTextColor(Color.parseColor("#3E3E3E"));
          text_gene[i].setTextColor(Color.parseColor("#3E3E3E"));
      }


    }
}